---
productname: "SONY BRAVIA KD65X7052PBU 65 Smart 4K Ultra HD HDR LED TV"
price: "20000"
path: "/product1"
image: ../../images/product1.jpg
---
Today we learn Html Today we learn Html Today we learn Html Today we learn Html Today we learn Html Today we learn Html Today we learn Html Today we learn Html Today we learn html

